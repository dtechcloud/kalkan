faketool test fixture
